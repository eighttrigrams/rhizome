// A URL pasted over selected prose makes the selection a markdown link to it:
// select "the spec", paste https://example.com, and get [the spec](https://example.com).
//
// Pure, like motions.js and fences.js — (text, from, to, pasted) in, a change or
// null out — so test/links_test.js can be a table of fixtures. The commands that
// apply it, for option+v and for the browser's own cmd+v, are in
// custom-commands.js; markdown mode is the only one that binds them.
//
// null means "an ordinary paste", and it is the answer whenever there is any
// doubt, because a paste that does something unasked is worse than one that
// does a little less than it could:
//
//   nothing selected        there is no text to make into a link
//   more than one line      link text cannot span a blank line, and a URL over
//                           a paragraph is far likelier a replacement
//   the clipboard is prose  only a whole URL, trimmed, is a link target
//   the selection is a URL  pasting a URL over a URL is replacing it
//   inside a fenced block   code, where [x](y) is just characters
//
// Whitespace at either edge of the selection — a double-click picks up the
// space after a word in some browsers — stays outside the brackets, so it reads
// [word](url) and not [word ](url).

import {fenceAt} from './fences.js';

// A scheme and "://", or mailto:, and no whitespace anywhere. Not a URL parser:
// the question is only whether the clipboard holds one address and nothing else.
const URL_RE = /^(?:[a-z][a-z0-9+.-]*:\/\/|mailto:)\S+$/i;

export function isUrl(s) {
  return URL_RE.test(s);
}

// The change that turns text[from, to) into a link to `pasted`, as
// {from, to, insert}, or null for an ordinary paste.
export function linkOver(text, from, to, pasted) {
  if (from >= to) return null;
  const url = pasted.trim();
  if (!isUrl(url)) return null;
  const selected = text.slice(from, to);
  if (selected.includes('\n')) return null;
  const core = selected.trim();
  if (!core || isUrl(core)) return null;
  if (fenceAt(text, from)) return null;
  const lead = selected.slice(0, selected.indexOf(core));
  const trail = selected.slice(lead.length + core.length);
  return {from, to, insert: lead + '[' + core + '](' + url + ')' + trail};
}
